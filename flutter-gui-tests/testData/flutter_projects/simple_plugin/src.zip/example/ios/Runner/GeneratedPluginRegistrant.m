//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"
#import <simple_plugin/SimplePlugin.h>

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [SimplePlugin registerWithRegistrar:[registry registrarForPlugin:@"SimplePlugin"]];
}

@end
