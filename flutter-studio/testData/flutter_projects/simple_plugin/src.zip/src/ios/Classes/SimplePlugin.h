#import <Flutter/Flutter.h>

@interface SimplePlugin : NSObject<FlutterPlugin>
@end
