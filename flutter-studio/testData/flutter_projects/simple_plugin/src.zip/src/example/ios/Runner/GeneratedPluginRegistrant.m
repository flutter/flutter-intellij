//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"

#if __has_include(<simple_plugin/SimplePlugin.h>)
#import <simple_plugin/SimplePlugin.h>
#else
@import simple_plugin;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [SimplePlugin registerWithRegistrar:[registry registrarForPlugin:@"SimplePlugin"]];
}

@end
